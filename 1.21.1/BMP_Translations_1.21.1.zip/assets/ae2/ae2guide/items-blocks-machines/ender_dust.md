---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Эндер пыль
  icon: ender_dust
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:ender_dust
---

# Эндер пыль

<ItemImage id="ender_dust" scale="4" />

Жемчуг эндера, раздробленный <ItemLink id="inscriber" />. Используется при производстве <ItemLink id="wireless_booster" />
и <ItemLink id="quantum_entangled_singularity" /> пар.

## Рецепт

<RecipeFor id="ender_dust" />
