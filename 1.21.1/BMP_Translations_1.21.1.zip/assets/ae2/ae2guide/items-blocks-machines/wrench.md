---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Гаечные ключи
  icon: certus_quartz_wrench
  position: 410
categories:
- tools
item_ids:
- ae2:certus_quartz_wrench
- ae2:nether_quartz_wrench
---

# Гаечные ключи
<Row>
  <ItemImage id="certus_quartz_wrench" scale="4" />

  <ItemImage id="nether_quartz_wrench" scale="4" />
</Row>

Гаечные ключи используются для вращения устройств ae2 (ПКМ) и разборки блоков ae2 (shift+ПКМ).
[Подчасти](../ae2-mechanics/cable-subparts.md) можно удалить из кабеля, не ломая все его части
(или кабель может быть удален без разрушения подчастей).

Многие блоки ae2 можно вращать, поэтому если в данном руководстве не сказано, что что-то можно вращать, это не значит, что этого нельзя делать.

## Рецепты

<Row>
  <RecipeFor id="certus_quartz_wrench" />

  <RecipeFor id="nether_quartz_wrench" />
</Row>
