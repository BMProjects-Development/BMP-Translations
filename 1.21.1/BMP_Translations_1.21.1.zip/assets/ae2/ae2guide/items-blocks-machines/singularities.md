---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Сингулярности
  icon: singularity
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:singularity
- ae2:quantum_entangled_singularity
---

# Сингулярности

<ItemImage id="singularity" scale="4" />

Очень компактный шар из материи.

Изготовлен с помощью 256 000 элементов или ведер в <ItemLink id="condenser" /> в режиме сингулярности.

## Квантовая запутанная сингулярность

<ItemImage id="quantum_entangled_singularity" scale="4" />

Требуется для создания соединения между двумя [Квантовыми сетями](quantum_bridge.md), они всегда создаются в соответствующих
парах. Для создания соединения поместите по 1 квантовой запутанной сингулярности из пары в <ItemLink id="quantum_link" /> моста с каждой стороны.

Они создаются, вызывая реакцию между <ItemLink id="minecraft:ender_pearl" /> или <ItemLink id="ender_dust" />\
и <ItemLink id="singularity" />. Любой взрывной силы должно быть достаточно для запуска реакции.

<RecipeFor id="quantum_entangled_singularity" />

***Почти любой взрыв - даже криперы - сработает.***

Всегда производятся парами, но требуют только одного <ItemLink id="singularity" />.

Неплохо было бы обозначить их именами, когда вы создаете их с помощью ванильной наковальни.