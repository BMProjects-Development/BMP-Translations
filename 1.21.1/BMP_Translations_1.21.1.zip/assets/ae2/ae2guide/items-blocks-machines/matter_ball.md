---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Шарик материи
  icon: matter_ball
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:matter_ball
---

# Шарик материи

<ItemImage id="matter_ball" scale="4" />

Шарик простейшей материи, аммуниция для <ItemLink id="matter_cannon" /> или ингредиент [шариков с краской](paintballs.md).

Создаётся из 256 любых предметов или вёдер жидкости в <ItemLink id="condenser" /> в режиме конденсации шариков материи.
