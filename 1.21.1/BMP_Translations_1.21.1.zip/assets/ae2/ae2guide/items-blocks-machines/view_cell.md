---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Ячейка просмотра
  icon: view_cell
  position: 410
categories:
- tools
item_ids:
- ae2:view_cell
---

# Ячейка просмотра

<ItemImage id="view_cell" scale="2" />

Ячейки просмотра используются для фильтрации отображения [терминалов](terminals.md). Вы разбиваете их на ячейки в <ItemLink id="cell_workbench" />.

Например, нужно, чтобы в терминале отображался только выбор каменных строительных материалов. Разделите ячейку представления на эти
материалы и поместите ее в терминал, и будут отображаться только эти элементы.

Ячейки просмотра аддитивны, если у вас есть ячейка просмотра для дубовых досок и ячейка просмотра для булыжника, то, поместив обе ячейки, вы увидите и доски, и булыжник.

## Рецепт

<Recipe id="network/cells/view_cell_storage" />

<Recipe id="network/cells/view_cell" />
