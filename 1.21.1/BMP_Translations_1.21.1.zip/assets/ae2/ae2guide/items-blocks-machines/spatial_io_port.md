---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Порт пространственного ввода-вывода
  icon: spatial_io_port
  position: 210
categories:
- devices 
item_ids:
- ae2:spatial_io_port
---

# Порт пространственного ввода-вывода

<BlockImage id="spatial_io_port" p:powered="true" scale="8" />

Порт пространственного ввода-вывода используется в [пространственным вводе-выводе](../ae2-mechanics/spatial-io.md), хранит [ячейку хранения пространства](spatial_cells.md)
и контролирует операцию ввод-вывода пространства.

Ячейка может быть помещена и извлечена из порта любой предметной логистикой (воронки, шины AE2 и т.п.), если вы хотите автоматизировать перемещение пространства.

## Рецепт

<RecipeFor id="spatial_io_port" />