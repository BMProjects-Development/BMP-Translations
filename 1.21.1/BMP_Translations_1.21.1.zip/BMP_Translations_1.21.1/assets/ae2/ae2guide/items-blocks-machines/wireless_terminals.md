---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Беспроводные терминалы
  icon: wireless_crafting_terminal
  position: 410
categories:
- tools
item_ids:
- ae2:wireless_terminal
- ae2:wireless_crafting_terminal
---

# Беспроводные терминалы

<Row>
  <ItemImage id="wireless_terminal" scale="4" />

  <ItemImage id="wireless_crafting_terminal" scale="4" />
</Row>

Беспроводные терминалы - это портативные версии обычных проводных [терминалов](terminals.md). Они имеют точно такой же пользовательский интерфейс, как и их
аналоги, за исключением того, что вместо слотов для <ItemLink id="view_cell" /> они имеют слоты для [карт улучшения](upgrade_cards.md).

Для сопряжения с сетью необходимо вставить терминал в правый верхний слот <ItemLink id="wireless_access_point" />,
подключенного к этой сети. (Слот с изображением беспроводного терминала и стрелкой под ним).

Для работы они должны находиться в радиусе действия <ItemLink id="wireless_access_point" />.

Их энергия может быть пополнена в <ItemLink id="charger" />.

# Беспроводной терминал

<ItemImage id="wireless_terminal" scale="4" />

Ваш базовый терминал, теперь портативный! Просматривайте содержимое [хранилища сети](../ae2-mechanics/import-export-storage.md), получайте доступ к нему
и запрашивайте вещи из вашего [автокрафта](../ae2-mechanics/autocrafting.md) в радиусе действия
<ItemLink id="wireless_access_point" />.

## Пользовательский интерфейс

См. раздел [терминалы](terminals.md)

## Улучшения

Беспроводной терминал поддерживает следующие [улучшения](upgrade_cards.md):

*   <ItemLink id="energy_card" /> для увеличения емкости аккумулятора

## Рецепт

<RecipeFor id="wireless_terminal" />

# Беспроводной терминал создания

<ItemImage id="wireless_crafting_terminal" scale="4" />

Беспроводной терминал создания похож на обычный беспроводной терминал, со всеми теми же настройками и разделами, но с дополнительной сеткой для крафта, которая будет автоматически
пополняться из [хранилища сети](../ae2-mechanics/import-export-storage.md). Будьте осторожны при нажатии клавиши shift на выходе!

## Пользовательский интерфейс

См. раздел [Терминалы](terminals.md)

## Улучшения:

Терминал поддерживает следующие [улучшения](upgrade_cards.md):

*   <ItemLink id="energy_card" /> для увеличения емкости аккумулятора

## Рецепт

<RecipeFor id="wireless_crafting_terminal" />
