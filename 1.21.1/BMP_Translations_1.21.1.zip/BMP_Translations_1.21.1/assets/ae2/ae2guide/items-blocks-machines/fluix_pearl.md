---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Изменчивый жемчуг
  icon: fluix_pearl
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:fluix_pearl
---

# Изменчивый жемчуг

<ItemImage id="fluix_pearl" scale="4" />

Эндер-жемчуг, покрытый <ItemLink id="fluix_crystal" />, используется при производстве некоторых компонентов AE2.

## Рецепт

<RecipeFor id="fluix_pearl" />
