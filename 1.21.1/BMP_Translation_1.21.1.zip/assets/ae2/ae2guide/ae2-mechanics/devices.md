---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: Устройства
  icon: interface
---

# Устройства

Под "устройством" понимается компонент сети AE2, выполняющий некоторую функцию, связанную с самой сетью. Они почти всегда
требуют наличия канала, за исключением [излучателя уровня](../items-blocks-machines/level_emitter.md).

В качестве примера можно привести:

*   <ItemLink id="interface" />
*   <ItemLink id="import_bus" />
*   <ItemLink id="storage_bus" />
*   <ItemLink id="pattern_provider" />
*   <ItemLink id="drive" />
