---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Режущие ножи
  icon: certus_quartz_cutting_knife
  position: 410
categories:
- tools
item_ids:
- ae2:certus_quartz_cutting_knife
- ae2:nether_quartz_cutting_knife
---

# Кварцевые инструменты

<Row>
  <ItemImage id="certus_quartz_cutting_knife" scale="4" />

  <ItemImage id="nether_quartz_cutting_knife" scale="4" />
</Row>

Режущие ножи используются для изготовления <ItemLink id="name_press" /> и <ItemLink id="cable_anchor" />.

Чтобы изготовить именной пресс, щелкните правой кнопкой мыши на режущем ноже и вставьте слиток металла, после чего вам нужно будет набрать имя, которое вы хотите написать на пластине.
затем просто извлеките готовую пластину.

## Рецепты

<Row>
  <RecipeFor id="certus_quartz_cutting_knife" />

  <RecipeFor id="nether_quartz_cutting_knife" />
</Row>
