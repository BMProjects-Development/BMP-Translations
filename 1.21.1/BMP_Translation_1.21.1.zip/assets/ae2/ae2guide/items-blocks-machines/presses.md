---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Прессы
  icon: silicon_press
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:silicon_press
- ae2:logic_processor_press
- ae2:calculation_processor_press
- ae2:engineering_processor_press
- ae2:name_press
---

# Прессы

В <ItemLink id="inscriber" /> используется 5 различных прессов.

<Row>
  <ItemImage id="silicon_press" scale="4" />

  <ItemImage id="logic_processor_press" scale="4" />

  <ItemImage id="calculation_processor_press" scale="4" />

  <ItemImage id="engineering_processor_press" scale="4" />
</Row>

<ItemImage id="name_press" scale="4" />

## Процессорные прессы

Прессы: "Кремниевый", "Логический", "Вычислительный" и "Инженерный" - используются при производстве [процессоров](processors.md).
Эти 4 пресса получаются при разбиении <ItemLink id="mysterious_cube" /> в [метеорите](../ae2-mechanics/meteorites.md).
Они также могут быть продублированы в <ItemLink id="inscriber" />.

<Column>
  <Row>
    <RecipeFor id="silicon_press" />

    <RecipeFor id="logic_processor_press" />
  </Row>

  <Row>
    <RecipeFor id="calculation_processor_press" />

    <RecipeFor id="engineering_processor_press" />
  </Row>
</Column>

## Именной пресс

Печатный пресс можно использовать в высекателе для присвоения имен предметам, подобно наковальне.

Для изготовления нажмите правой кнопкой мыши на <ItemLink id="certus_quartz_cutting_knife" /> или <ItemLink id="nether_quartz_cutting_knife" />
и вставьте слиток металла, после чего вам нужно будет ввести имя, которое вы хотите написать на табличке.
Затем нужно напечатать имя на пластине и просто извлечь готовую пластину. В программе можно использовать одну или две пластины одновременно,
Если вы используете две пластины, то имя будет напечатано комбинацией обоих имен, верхний слот, затем нижний слот.
