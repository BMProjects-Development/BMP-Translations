---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Кварцевые светильники
  icon: quartz_fixture
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:quartz_fixture
- ae2:light_detector
---

# Кварцевые светильники
<Row>
<BlockImage id="quartz_fixture" scale="8" />

<BlockImage id="light_detector" scale="8" />
</Row>

Приспособление с заряженным кварцем представляет собой маленький прибор, излучающий свет.

Приспособление, обнаруживающее свет, вместо этого излучает сигнал красного камня в зависимости от уровня освещенности своего блока.

## Рецепты

<RecipeFor id="quartz_fixture" />

<RecipeFor id="light_detector" />
