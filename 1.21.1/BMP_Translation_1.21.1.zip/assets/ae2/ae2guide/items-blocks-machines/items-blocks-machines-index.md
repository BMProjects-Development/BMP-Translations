---
navigation:
  title: Предметы, блоки и механизмы
  position: 50
---

# Предметы, блоки и механизмы

Список вещей в моде для других страниц, на которые можно ссылаться, и объяснение их назначения.

## Разные ингредиенты и блоки

<CategoryIndex category="misc ingredients blocks" />

## Сетевая инфраструктура

<CategoryIndex category="network infrastructure" />

## Устройства

<CategoryIndex category="devices" />

## Механизмы

<CategoryIndex category="machines" />

## Инструменты

<CategoryIndex category="tools" />