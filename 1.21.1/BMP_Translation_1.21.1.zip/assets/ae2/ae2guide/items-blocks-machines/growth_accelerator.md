---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Ускоритель роста
  icon: growth_accelerator
  position: 310
categories:
- machines
item_ids:
- ae2:growth_accelerator
---

# Ускоритель роста

<BlockImage id="growth_accelerator" p:powered="true" scale="8"/>

Массово ускоряет [рост](../ae2-mechanics/certus-growth.md) кристаллов кварца или аметиста, когда установлен рядом с цветущим блоком.

Интересно, что он *также* может ускорять рост различных растений.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/growth_accelerator.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Для ручного питания установите <ItemLink id="crank" /> всерху или снизу и выполните щелчок правой кнопкой мыши.

Он соединяется только с кабелями на своих концах, где находятся розовые элементы.

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/accelerator_connections.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Recipe

<RecipeFor id="growth_accelerator" />
