---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Изменчивый блок
  icon: fluix_block
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:fluix_block
---

# Изменчивый блок

<BlockImage id="fluix_block" scale="8" />

Блок хранения для <ItemLink id="fluix_crystal" />. Он также используется в рецептах для нескольких механизмов.

## Рецепт

<RecipeFor id="fluix_block" />
