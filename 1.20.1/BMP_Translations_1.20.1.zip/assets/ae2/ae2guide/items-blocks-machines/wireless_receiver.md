---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Беспроводной приёмник
  icon: wireless_receiver
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:wireless_receiver
---

# Беспроводной приёмник

<ItemImage id="wireless_receiver" scale="4" />

<ItemLink id="fluix_pearl" /> в отражательной антенне - элементе технологии беспроводной связи малого радиуса.

## Рецепт

<RecipeFor id="wireless_receiver" />
