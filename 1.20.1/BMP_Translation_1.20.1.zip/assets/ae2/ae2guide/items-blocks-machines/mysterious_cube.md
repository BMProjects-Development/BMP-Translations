---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Таинственный куб
  icon: mysterious_cube
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:mysterious_cube
- ae2:not_so_mysterious_cube
---

# Tаинственный куб

<BlockImage id="mysterious_cube" scale="8" />

Помните, как вам приходилось искать кучу метеоров, чтобы найти все прессы? Больше не надо! Теперь метеориты приходят с Таинственным Кубом.

Интересно, что будет, если его разбить (без прикосновения шелка)...

Вы также можете сделать его копию - "Не такой уж таинственный куб".

## Рецепт

<RecipeFor id="not_so_mysterious_cube" />
