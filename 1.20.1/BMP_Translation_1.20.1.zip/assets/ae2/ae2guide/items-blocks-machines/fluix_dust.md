---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Изменчивая пыль
  icon: fluix_dust
  position: 010
categories:
- misc ingredients blocks
categories:
- network infrastructure
item_ids:
- ae2:fluix_dust
---

# Изменчивая пыль

<ItemImage id="fluix_dust" scale="4" />

<ItemLink id="fluix_crystal" /> который был раздроблен <ItemLink id="inscriber" />. Используется в производстве
нескольких механизмов и компонентов AE2.

## Рецепт

<RecipeFor id="fluix_dust" />
