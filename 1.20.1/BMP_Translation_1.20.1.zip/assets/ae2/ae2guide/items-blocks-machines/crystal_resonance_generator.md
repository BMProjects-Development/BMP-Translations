---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Кристаллический резонирующий генератор
  icon: crystal_resonance_generator
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:crystal_resonance_generator
---

# Кристаллический резонирующий генератор

<BlockImage id="crystal_resonance_generator" scale="8" />

Это устройство может генерировать энергию для вашей сети МЭ без использования топлива. Из-за кристаллических вибраций, которые создаёт это устройство, только один генератор может быть использован в одной сети. От этих вибраций не защищает даже <ItemLink id="quartz_fiber" />.

**Generation Rate:** <ae2:ConfigValue name="crystalResonanceGeneratorRate"/> AE/t

## Рецепт

<RecipeFor id="crystal_resonance_generator" />
